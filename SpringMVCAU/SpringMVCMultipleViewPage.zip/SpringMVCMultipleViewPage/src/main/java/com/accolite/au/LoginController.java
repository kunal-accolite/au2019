package com.accolite.au;

import java.util.Date;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

	private static Map<String, User> hm = new HashMap<String, User>();

	@RequestMapping("/kunal")
	public String login(Model m) {
		return "welcome";
	}


	@RequestMapping("/juneja")
	public String loginUser(HttpServletRequest req, Model m) {

		String username = req.getParameter("username");

		String password = req.getParameter("password");

		if (!hm.containsKey(username)) 
		{
			User user = new User(username, password, 0);
			hm.put(username, user);
			return "success";
		}
		
		else 
		{
			
			if (hm.get(username).getPassword().compareTo(password) == 0) 
			{
				
				if(hm.get(username).ts!=null&&new Timestamp(new Date().getTime()).compareTo(hm.get(username).ts)<0)
				{
					return "failed";
				}
				
				else 
				{
					hm.get(username).setCount(0);
					return "success";
				}
			} 
			
			else 
			{
				User user = hm.get(username);
				int count = user.getCount();
				count = count + 1;
				User user1 = new User(user.getUsername(), user.getPassword(), count);
				hm.replace(username, user, user1);
				
				if (count > 3)
				{
					user1.ts=new Timestamp(new Date().getTime()+60000);
					hm.get(username).setCount(0);
					return "failed";
				}
				
				else
				{
					String value="Wrong Credentials ! Try again";
					m.addAttribute("value", value);
					return "welcome";
				}
				
			}
		}
	}
}
