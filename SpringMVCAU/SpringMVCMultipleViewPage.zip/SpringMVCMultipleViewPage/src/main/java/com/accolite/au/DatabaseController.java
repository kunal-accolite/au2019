package com.accolite.au;

import java.sql.Timestamp;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DatabaseController {
	public Session getsession()
	{
		Configuration con=new Configuration().configure("hibernate.cfg.xml");
		StandardServiceRegistryBuilder ssrb = new StandardServiceRegistryBuilder()
				.applySettings(con.getProperties());
		SessionFactory sessionFactory = con.buildSessionFactory(ssrb.build());
		Session session = sessionFactory.openSession();
		return session;
		
	}
	
	@RequestMapping("/login")
	public String login(Model m) {
		return "welcome";
	}
	
	@RequestMapping("/user")
	public String loginUser(HttpServletRequest req,Model m)
	{
			DatabaseController dc=new DatabaseController();
			Session session=dc.getsession();
			String username = req.getParameter("username");
			String password = req.getParameter("password");
				Transaction tx=session.beginTransaction();
				Timestamp ts=new Timestamp(new Date().getTime());
				User user=new User(username,password,0,ts);
				session.save(user);
				tx.commit();

				return "success";
				
			
			
//			else 
//			{
//				
//				if (hm.get(username).getPassword().compareTo(password) == 0) 
//				{
//					
//					if(hm.get(username).ts!=null&&new Timestamp(new Date().getTime()).compareTo(hm.get(username).ts)<0)
//					{
//						return "failed";
//					}
//					
//					else 
//					{
//						hm.get(username).setCount(0);
//						return "success";
//					}
//				} 
//				
//				else 
//				{
//					User user = hm.get(username);
//					int count = user.getCount();
//					count = count + 1;
//					User user1 = new User(user.getUsername(), user.getPassword(), count);
//					hm.replace(username, user, user1);
//					
//					if (count > 3)
//					{
//						user1.ts=new Timestamp(new Date().getTime()+60000);
//						hm.get(username).setCount(0);
//						return "failed";
//					}
//					
//					else
//					{
//						String value="Wrong Credentials ! Try again";
//						m.addAttribute("value", value);
//						return "welcome";
//					}
//					
//				}
		
	}

}
