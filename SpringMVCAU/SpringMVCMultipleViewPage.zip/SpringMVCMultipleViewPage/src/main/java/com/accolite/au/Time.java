package com.accolite.au;

import java.sql.Timestamp;
import java.util.Date;

public class Time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date=new Date();
		Timestamp ts=new Timestamp(date.getTime()+300000);
		System.out.println(ts);
		

	}

}
