package com.accolite.au;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AUController {
	@RequestMapping("/hello")
	public String greet(Model m) {
		
		String message= "hello au";
		m.addAttribute("message", message);
		return "hello";
	}
	
	@RequestMapping("/welcome")
	public String greeting(Model m) {
		String kk="hello kunal";
		m.addAttribute("kk", kk);
		return "kunal";
	}
}
